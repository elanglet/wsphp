<?php

require_once('../autoload.php');

$auteurDAO = DAOFactory::getInstance()->getAuteurDAO();

echo "<pre>";
$auteur = new Auteur();
$auteur->setPrenom("Robert");
$auteur->setNom("DUPONT");
$auteur->setIdentifiant("rdupont");
$auteur->setMotDePasse("password");
print_r($auteurDAO->ajouterAuteur($auteur));
echo "</pre>";

echo "<hr />";

echo "<pre>";
print_r($auteurDAO->rechercherAuteurParIdentifiant('rdupont'));
echo "</pre>";

echo "<hr />";

echo "<pre>";
print_r($auteurDAO->authentifier('rdupont', 'password'));
echo "</pre>";

echo "<hr />";

echo "<pre>";
print_r($auteurDAO->supprimerAuteur('rdupont'));
echo "</pre>";

echo "<hr />";

echo "<pre>";
print_r($auteurDAO->rechercherAuteurParIdentifiant('rdupont'));
echo "</pre>";