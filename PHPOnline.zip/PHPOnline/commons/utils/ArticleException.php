<?php

/**
 * Description of ArticleException
 *
 * @author Etienne
 */
class ArticleException extends Exception { }
