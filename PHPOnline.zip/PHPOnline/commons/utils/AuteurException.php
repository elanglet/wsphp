<?php

/**
 * Description of ArticleException
 *
 * @author Etienne
 */
class AuteurException extends Exception { }
