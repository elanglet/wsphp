<?php

/**
 * Description of Auteur
 *
 * @author Etienne
 */
class Auteur {

    private $identifiant;
    private $motDePasse;
    private $nom;
    private $prenom;

    public function getIdentifiant() {
        return $this->identifiant;
    }

    public function getMotDePasse() {
        return $this->motDePasse;
    }

    public function getNom() {
        return $this->nom;
    }

    public function getPrenom() {
        return $this->prenom;
    }

    public function setIdentifiant($identifiant) {
        $this->identifiant = $identifiant;
    }

    public function setMotDePasse($motDePasse) {
        $this->motDePasse = $motDePasse;
    }

    public function setNom($nom) {
        $this->nom = $nom;
    }

    public function setPrenom($prenom) {
        $this->prenom = $prenom;
    }


    
}
