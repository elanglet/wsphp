<?php

/**
 * Description of Administrateur
 *
 * @author Etienne
 */
class Administrateur extends Auteur { }
