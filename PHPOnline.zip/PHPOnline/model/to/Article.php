<?php

/**
 * Description of Article
 *
 * @author Etienne
 */
class Article {
    
    private $id;
    private $titre;
    private $intro;
    private $texte;
    private $datePublication;
    private $categorie;
    private $auteur;

    public function getId() {
        return $this->id;
    }

    public function getTitre() {
        return $this->titre;
    }

    public function getIntro() {
        return $this->intro;
    }

    public function getTexte() {
        return $this->texte;
    }

    public function getCategorie() {
        return $this->categorie;
    }

    public function getDatePublication() {
        return $this->datePublication;
    }

    public function getAuteur() {
        return $this->auteur;
    }

    public function setId($id) {
        $this->id = $id;
    }

    public function setTitre($titre) {
        $this->titre = $titre;
    }

    public function setIntro($intro) {
        $this->intro = $intro;
    }

    public function setTexte($texte) {
        $this->texte = $texte;
    }

    public function setCategorie($categorie) {
        $this->categorie = $categorie;
    }

    public function setDatePublication($datePublication) {
        $this->datePublication = $datePublication;
    }

    public function setAuteur($auteur) {
        $this->auteur = $auteur;
    }

}
