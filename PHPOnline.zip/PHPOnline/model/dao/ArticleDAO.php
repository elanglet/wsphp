<?php

/**
 *
 * @author Etienne
 */
interface ArticleDAO {
    
    function rechercherTousLesArticles();
    
    function rechercherArticleParId($id);
    
    function rechercherArticleParAuteur($auteur);
    
    function rechercherArticleParCategorie($categorie);
    
    function ajouterArticle(Article $article);
    
    function supprimerArticle($id);
    
    function modifierArticle(Article $article);
    
}
