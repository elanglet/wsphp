<?php

/**
 *
 * @author Etienne
 */
interface AuteurDAO {
    
    function authentifier($identifiant, $motDePasse);
    
    function rechercherAuteurParIdentifiant($identifiant);
       
    function rechercherListeAuteurs();

    function ajouterAuteur(Auteur $auteur);
    
    function supprimerAuteur($identifiant);
    
}
