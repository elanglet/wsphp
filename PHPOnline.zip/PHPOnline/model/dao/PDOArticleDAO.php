<?php

/**
 * Description of PDOArticleDAO
 *
 * @author Etienne
 */
class PDOArticleDAO implements ArticleDAO {

    public function ajouterArticle(Article $article) {
        $db = null;
        try {
            $db = Connection::get();
            $sql = "INSERT INTO article(titre,intro,texte,datepublication,categorie,auteur) VALUES(?,?,?,?,?,?)";
            $st = $db->prepare($sql);
            $st->bindParam(1, $article->getTitre());
            $st->bindParam(2, $article->getIntro());
            $st->bindParam(3, $article->getTexte());
            $st->bindParam(4, $article->getDatePublication());
            $st->bindParam(5, $article->getCategorie()->getNom());
            $st->bindParam(6, $article->getAuteur()->getIdentifiant());
            $st->execute();
            Connection::release($db);
        } 
        catch (Exception $e) {
            Connection::release($db);
            throw new ArticleException("Erreur lors de l'insertion de l'article.", 0, $e);
        }
    }

    public function modifierArticle(Article $article) {
        $db = null;
        try {
            $db = Connection::get();
            $sql = "UPDATE article SET titre=?,intro=?,texte=?,datepublication=?,categorie=? WHERE id=?";
            $st = $db->prepare($sql);
            $st->bindParam(1, $article->getTitre());
            $st->bindParam(2, $article->getIntro());
            $st->bindParam(3, $article->getTexte());
            $st->bindParam(4, $article->getDatePublication());
            $st->bindParam(5, $article->getCategorie()->getNom());
            $st->bindParam(6, $article->getId());
            $st->execute();
            Connection::release($db);
        }
        catch (Exception $e) {
            Connection::release($db);
            throw new ArticleException("Erreur de suppression de l'article.", 0, $e);
        }
    }

    public function rechercherArticleParAuteur($identifiantAuteur) {
        $db = null;
        try {
            $db = Connection::get();
            $sql = "SELECT a.id,a.titre,a.intro,a.texte,a.datepublication,u.nom,u.prenom,c.nom FROM article a JOIN auteur u ON a.auteur = u.identifiant JOIN categorie c ON a.categorie = c.nom WHERE u.identifiant=?";
            $st = $db->prepare($sql);
            $st->bindParam(1, $identifiantAuteur);
            $st->execute();
            $listeArticles = array();
            $auteur = new Auteur();
            while($enreg = $st->fetch()) {
                $auteur->setNom($enreg[5]);
                $auteur->setPrenom($enreg[6]);   
                $auteur->setIdentifiant($identifiantAuteur);
                $categorie = new Categorie($enreg[7]);
                $article = new Article();
                $article->setId($enreg[0]);
                $article->setTitre($enreg[1]);
                $article->setIntro($enreg[2]);
                $article->setTexte($enreg[3]);
                $article->setDatePublication($enreg[4]);
                $article->setAuteur($auteur);
                $article->setCategorie($categorie);
                $listeArticles[] = $article;
            }
            Connection::release($db);
            return $listeArticles;
        }
        catch (Exception $e) {
            Connection::release($db);
            throw new ArticleException("Erreur de récupération des articles.", 0, $e);
        }
    }

    public function rechercherArticleParCategorie($nomCategorie) {
        $db = null;
        try {
            $db = Connection::get();
            $sql = "SELECT a.id,a.titre,a.intro,a.texte,a.datepublication,u.nom,u.prenom,u.identifiant FROM article a JOIN auteur u ON a.auteur = u.identifiant JOIN categorie c ON a.categorie = c.nom WHERE c.nom=?";
            $st = $db->prepare($sql);
            $st->bindParam(1, $nomCategorie);
            $st->execute();
            $listeArticles = array();
            $categorie = new Categorie($nomCategorie);
            while($enreg = $st->fetch()) {
                $auteur = new Auteur();
                $auteur->setNom($enreg[5]);
                $auteur->setPrenom($enreg[6]);   
                $auteur->setIdentifiant($enreg[7]);
                $article = new Article();
                $article->setId($enreg[0]);
                $article->setTitre($enreg[1]);
                $article->setIntro($enreg[2]);
                $article->setTexte($enreg[3]);
                $article->setDatePublication($enreg[4]);
                $article->setAuteur($auteur);
                $article->setCategorie($categorie);
                $listeArticles[] = $article;
            }
            Connection::release($db);
            return $listeArticles;
        }
        catch (Exception $e) {
            Connection::release($db);
            throw new ArticleException("Erreur de récupération des articles.", 0, $e);
        }
    }

    public function rechercherArticleParId($id) {
        $db = null;
        try {
            $db = Connection::get();
            $sql = "SELECT a.titre,a.intro,a.texte,a.datepublication,u.nom,u.prenom,u.identifiant,c.nom FROM article a JOIN auteur u ON a.auteur = u.identifiant JOIN categorie c ON a.categorie = c.nom WHERE a.id=?";
            $st = $db->prepare($sql);
            $st->bindParam(1, $id);
            $st->execute();
            
            if($enreg = $st->fetch()) {
                $auteur = new Auteur();
                $auteur->setNom($enreg[4]);
                $auteur->setPrenom($enreg[5]);   
                $auteur->setIdentifiant($enreg[6]);
                
                $categorie = new Categorie($enreg[7]);
                
                $article = new Article();
                $article->setId($id);
                $article->setTitre($enreg[0]);
                $article->setIntro($enreg[1]);
                $article->setTexte($enreg[2]);
                $article->setDatePublication($enreg[3]);
                $article->setAuteur($auteur);
                $article->setCategorie($categorie);
                Connection::release($db);
                
                return $article;
            }
            else {
                Connection::release($db);
                throw new ArticleException("Identifiant d'article inexistant.");
            }
        }
        catch (Exception $e) {
            Connection::release($db);
            throw new ArticleException("Erreur de récupération des articles.", 0, $e);
        }
    }

    public function rechercherTousLesArticles() {
        $db = null;
        try {
            $db = Connection::get();
            $sql = "SELECT a.id,a.titre,a.intro,a.texte,a.datepublication,u.nom,u.prenom,u.identifiant,c.nom FROM article a JOIN auteur u ON a.auteur = u.identifiant JOIN categorie c ON a.categorie = c.nom";
            $result = $db->query($sql);
            $listeArticles = array();
            
            while($enreg = $result->fetch()) {
                $auteur = new Auteur();
                $auteur->setNom($enreg[5]);
                $auteur->setPrenom($enreg[6]);   
                $auteur->setIdentifiant($enreg[7]);
                
                $categorie = new Categorie($enreg[8]);
                
                $article = new Article();
                $article->setId($enreg[0]);
                $article->setTitre($enreg[1]);
                $article->setIntro($enreg[2]);
                $article->setTexte($enreg[3]);
                $article->setDatePublication($enreg[4]);
                $article->setAuteur($auteur);
                $article->setCategorie($categorie);
                $listeArticles[] = $article;
            }
            Connection::release($db);
            return $listeArticles;
        }
        catch (Exception $e) {
            Connection::release($db);
            throw new ArticleException("Erreur de récupération des articles.", 0, $e);
        }        
    }

    public function supprimerArticle($id) {
        $db = null;
        try {
            $db = Connection::get();
            $sql = "DELETE FROM article WHERE id=?";
            $st = $db->prepare($sql);
            $st->bindParam(1, $id);
            $st->execute();
            Connection::release($db);
        } 
        catch (Exception $e) {
            Connection::release($db);
            throw new ArticleException("Erreur de suppression de l'article.", 0, $e);
        }
    }

}
