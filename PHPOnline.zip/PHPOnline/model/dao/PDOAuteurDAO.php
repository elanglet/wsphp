<?php

/**
 * Description of PDOAuteurDAO
 *
 * @author Etienne
 */
class PDOAuteurDAO implements AuteurDAO {
    
    public function ajouterAuteur(Auteur $auteur) {
        $db = null;
        try {
            if($this->verifierExistanceAuteur($auteur)) {
                throw new AuteurException("Identifiant existant !.");
            }
            $db = Connection::get();
            $sql = "INSERT INTO auteur(identifiant,motdepasse,prenom,nom) VALUES(?,?,?,?)";
            $st = $db->prepare($sql);
            $st->bindParam(1, $auteur->getIdentifiant());
            $st->bindParam(2, md5($auteur->getMotDePasse()));
            $st->bindParam(3, $auteur->getPrenom());
            $st->bindParam(4, $auteur->getNom());
            $st->execute();
            Connection::release($db);
        }
        catch (Exception $e) {
            Connection::release($db);
            throw new AuteurException("Erreur d'ajout de l'auteur.", 0, $e);
        }
    }

    public function authentifier($identifiant, $motDePasse) {
        try {
            $auteur = $this->rechercherAuteurParIdentifiant($identifiant);
            if(md5($motDePasse) === $auteur->getMotDePasse()) {
                return $auteur;
            }
            else {
                throw new Exception();
            }
        } 
        catch (Exception $e) {
            throw new AuteurException("Erreur d'autentification.", 0, $e);
        }
    }

    public function rechercherAuteurParIdentifiant($identifiant) {
        $db = null;
        try {
            $db = Connection::get();
            $sql = "SELECT motdepasse,nom,prenom FROM auteur WHERE identifiant=?";
            $st = $db->prepare($sql);
            $st->bindParam(1, $identifiant);
            $st->execute();
            if($enreg = $st->fetch()) {
                $auteur = new Auteur();
                $auteur->setIdentifiant($identifiant);
                $auteur->setMotDePasse($enreg['motdepasse']);
                $auteur->setNom($enreg['nom']);
                $auteur->setPrenom($enreg['prenom']);
                Connection::release($db);
                return $auteur;
            }
            else {
                Connection::release($db);
                throw new AuteurException();
            }
        }
        catch(AuteurException $e) {
            throw new AuteurException("Aucun auteur avec cet identifiant.");
        }
        catch (Exception $e) {
            Connection::release($db);
            throw new AuteurException("Erreur de récupération de l'auteur.", 0, $e);
        }
    }

    public function rechercherListeAuteurs() {
        $db = null;
        try {
            $db = Connection::get();
            $sql = "SELECT identifiant,motdepasse,nom,prenom FROM auteur";
            $result = $db->query($sql);
            $listeAuteurs = array();
            while($enreg = $result->fetch()) {
                $auteur = new Auteur();
                $auteur->setIdentifiant($enreg['identifiant']);
                $auteur->setMotDePasse($enreg['motdepasse']);
                $auteur->setNom($enreg['nom']);
                $auteur->setPrenom($enreg['prenom']);
                Connection::release($db);
                $listeAuteurs[] = $auteur;
            }
            return $listeAuteurs;
        }
        catch (Exception $e) {
            Connection::release($db);
            throw new AuteurException("Erreur de récupération de la liste des auteurs.", 0, $e);
        }
    }
    
    private function verifierExistanceAuteur($auteur) {
        try {
            $this->rechercherAuteurParIdentifiant($auteur->getIdentifiant());
            return true;
        } 
        catch (Exception $e) {
            return false;
        }
    }
    
    public function supprimerAuteur($identifiant) {
        $db = null;
        try {
            $db = Connection::get();
            $sql = "DELETE FROM auteur WHERE identifiant=?";
            $st = $db->prepare($sql);
            $st->bindParam(1, $identifiant);
            $st->execute();
            Connection::release($db);
        } 
        catch (Exception $e) {
            Connection::release($db);
            throw new AuteurException("Erreur de suppression de l'auteur.", 0, $e);
        }
    }

}
