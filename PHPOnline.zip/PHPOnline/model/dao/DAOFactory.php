<?php

/**
 * Description of DAOFactory
 *
 * @author Etienne
 */
class DAOFactory {

    private static $instance;
    
    private function __construct() {}
    
    public static function getInstance() {
        if (self::$instance == null) {
            self::$instance = new DAOFactory ();
        }

        return self::$instance;
    }
    
    public function getArticleDAO() {
        return new PDOArticleDAO();
    }
    
    public function getAuteurDAO() {
        return new PDOAuteurDAO();
    }

//     public function getAdministrateurDAO() {
//         return new PDOAdministrateurDAO();
//     }
    
//     public function getTicketDAO() {
//         return new PDOTicketDAO();
//     }    
}