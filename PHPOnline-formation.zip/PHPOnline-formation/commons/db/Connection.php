<?php

/**
 * Description of Connexion
 *
 * @author Etienne
 */
class Connection {
    
    const URL  = "mysql:host=localhost;dbname=phponline";
    const USER = "root";
    const PWD = "";
    
    public static function get() {
        try {
            $db = new PDO(self::URL, self::USER, self::PWD);
            $db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
            return $db;            
        } 
        catch (PDOException $e) {
            throw new ArticleException("Erreur de connexion à la base de données.", 0, $e);
        }   
    }
    
    public static function release($db) {
        $db = null;
    }
    
}
