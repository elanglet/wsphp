<?php
/*
 * Les fonctions qui sont exposées par Slim et qui font le lien avec le composant DAO.
 * Ces fonctions doivent respecter la signature des fonctions Slim : 
 * 
 *   function maFonction(Request $request, Response $response, array $args)
 *  
 */

use Psr\Http\Message\ResponseInterface as Response;
use Psr\Http\Message\ServerRequestInterface as Request;

function ajouter(Request $request, Response $response, array $args) {
    
}

function rechercherParId(Request $request, Response $response, array $args) {
    // On récupère l'id de l'article dans l'URL
    $id = $args['id'];
    
    // On appelle la fonctionnalité du DAO pour récupérer l'objet Article
    $dao = DAOFactory::getInstance()->getArticleDAO();
    $objetArticle = $dao->rechercherArticleParId($id);
    
    // On transforme l'objet Article en tableau associatif
    $article['id'] = $objetArticle->getId();
    $article['titre'] = $objetArticle->getTitre();
    $article['intro'] = $objetArticle->getIntro();
    $article['texte'] = $objetArticle->getTexte();
    $article['datePublication'] = $objetArticle->getDatePublication();
    $article['auteur'] = $objetArticle->getAuteur()->getIdentifiant();
    $article['categorie'] = $objetArticle->getCategorie()->getNom();
    
    // On créé un flux JSON à partir du tableau associatif
    $json = json_encode($article);    
    
    // On précise que la réponse est au format JSON
    $response = $response->withHeader('Content-Type', 'application/json');
    
    // On renvoi le flux JSON dans la réponse
    $body = $response->getBody();
    $body->write($json);
    return $response;

// Avec Slim 3 on peut aussi écrire : 
//     $response->withJson($article);
//     return $response;
}

function rechercherTous(Request $request, Response $response, array $args) {
    // On délègue l'appel au DAO...
    $dao = DAOFactory::getInstance()->getArticleDAO();
    $listeObjetsArticle = $dao->rechercherTousLesArticles();
    
    // On transforme le tableau d'objets Article en tableau de tableaux associatifs.
    $listeArticles = array();
    foreach($listeObjetsArticle as $objetArticle) {
        $article['id'] = $objetArticle->getId();
        $article['titre'] = $objetArticle->getTitre();
        $article['intro'] = $objetArticle->getIntro();
        $article['texte'] = $objetArticle->getTexte();
        $article['datePublication'] = $objetArticle->getDatePublication();
        $article['auteur'] = $objetArticle->getAuteur()->getIdentifiant();
        $article['categorie'] = $objetArticle->getCategorie()->getNom();
        
        $listeArticles[] = $article;
    }
    
    // On créé un flux JSON à partir du tableau associatif
    $json = json_encode($listeArticles);
    
    // On précise que la réponse est au format JSON
    $response = $response->withHeader('Content-Type', 'application/json');
    
    // On renvoi le flux JSON dans la réponse
    $body = $response->getBody();
    $body->write($json);
    return $response;
}
