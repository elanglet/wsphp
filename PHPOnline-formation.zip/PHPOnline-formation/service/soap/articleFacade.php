<?php
/*
 * Ce fichier contient les fonctions à exposer dans le service.
 * Elles font le lien avec la couche métier d'accès aux données. 
 */


/**
 * Fonction permettant d'ajouter un article. 
 * 
 * @param $article Les données de l'article à insérer.
 * @return Pas de valeur retournée.
 */
function ajouter($article) {
    // On capture les exceptions ...
    try {
        // On transforme le tableau associatif PHP arrivant via SOAP, en objet Article.
        $objetArticle = new Article();
        $objetArticle->setId($article['id']);
        $objetArticle->setTitre($article['titre']);
        $objetArticle->setIntro($article['intro']);
        $objetArticle->setTexte($article['texte']);
        $objetArticle->setDatePublication($article['datePublication']);
        
        $objetAuteur = new Auteur();
        $objetAuteur->setIdentifiant($article['auteur']);
        
        $objetArticle->setAuteur($objetAuteur);
        
        $objetCategorie = new Categorie($article['categorie']);
        
        $objetArticle->setCategorie($objetCategorie);
        
        // On délègue l'appel au DAO...
        $dao = DAOFactory::getInstance()->getArticleDAO();
        $dao->ajouterArticle($objetArticle);
    }
    // ... et on produit une SoapFault
    catch(Exception $e) {
        // On instancie et on renvoi un objet nusoap_fault
        return new nusoap_fault(
            "SOAP-ENV:Server",          // Code
            $e->getMessage(),           // Fault String (Message)
            "",                         // Fault Actor
            $e->getTraceAsString()      // Fault Detail
        );
    }
}

/**
 * Fonction permettant de récuper un article par son id.
 * 
 * @param $id L'identifiant de l'article.
 * @return L'article extrait de la base.
 */
function rechercherParId($id) {
    // On capture les exceptions ...
    try {
        // On délègue l'appel au DAO...
        $dao = DAOFactory::getInstance()->getArticleDAO();
        $objetArticle = $dao->rechercherArticleParId($id);
        
        // On créé le tableau associatif pour SOAP à partir de l'objet Article.
        $article['id'] = $objetArticle->getId();
        $article['titre'] = $objetArticle->getTitre();
        $article['intro'] = $objetArticle->getIntro();
        $article['texte'] = $objetArticle->getTexte();
        $article['datePublication'] = $objetArticle->getDatePublication();
        $article['auteur'] = $objetArticle->getAuteur()->getIdentifiant();
        $article['categorie'] = $objetArticle->getCategorie()->getNom();
        
        // On encapsule les données de retour dans un objet soapval
        // tns:Article fait référence au type XMLSchema représentant un article en SOAP.
        return new soapval('result', 'tns:Article', $article);
    }
    // ... et on produit une SoapFault
    catch(Exception $e) {
        // On instancie et on renvoi un objet nusoap_fault
        return new nusoap_fault(
            "SOAP-ENV:Server",          // Code
            $e->getMessage(),           // Fault String (Message)
            "",                         // Fault Actor
            $e->getTraceAsString()      // Fault Detail
        );
    }
}

/**
 * Fonction permettant d'obtenir la liste de tous les articles.
 * 
 * @return Un tableau de tous les articles de la base.
 */
function rechercherTous() {
    // On capture les exceptions ...
    try {
        // On délègue l'appel au DAO...
        $dao = DAOFactory::getInstance()->getArticleDAO();
        $listeObjetsArticle = $dao->rechercherTousLesArticles();
        
        // On transforme le tableau d'objets Article en tableau de tableaux associatifs.
        $listeArticles = array();
        foreach($listeObjetsArticle as $objetArticle) {
            $article['id'] = $objetArticle->getId();
            $article['titre'] = $objetArticle->getTitre();
            $article['intro'] = $objetArticle->getIntro();
            $article['texte'] = $objetArticle->getTexte();
            $article['datePublication'] = $objetArticle->getDatePublication();
            $article['auteur'] = $objetArticle->getAuteur()->getIdentifiant();
            $article['categorie'] = $objetArticle->getCategorie()->getNom();
            
            $listeArticles[] = $article;
        }
        
        // On encapsule les données de retour dans un objet soapval
        // tns:ArrayOfArticle fait référence au type XMLSchema représentant un tableau d'articles en SOAP.
        return new soapval('result', 'tns:ArrayOfArticle', $listeArticles);
    }
    // ... et on produit une SoapFault
    catch(Exception $e) {
        // On instancie et on renvoi un objet nusoap_fault
        return new nusoap_fault(
            "SOAP-ENV:Server",          // Code
            $e->getMessage(),           // Fault String (Message)
            "",                         // Fault Actor
            $e->getTraceAsString()      // Fault Detail
        );
    }
}



