<?php
/*
 *  Ce fichier contient le Endpoint du service SOAP.
 *  
 *  L'URL d'accès au service sera : http://localhost/PHPOnline/service/soap/article.php
 */

require_once('../../autoload.php');
require_once('articleFacade.php');

// 1. Désactivation du cache de WSDL
ini_set('soap.wsdl_cache_enabled', '0');

// 2. Création du service
$service = new nusoap_server();

// Configuration du service pour gérer les problématiques d'encodage !
$service->soap_defencoding = 'UTF-8';
$service->decode_utf8 = false;
$service->encode_utf8 = true;

// 3. Génération du WSDL.
$service->configureWSDL(
    'ArticleService',                               // Nom du service
    'http://www.formation.fr/service/pol/article',  // URI d'espace de nom du service   
    false,                                          // literal    
    'document'                                      // document
);

// 4. Déclaration des types de données complexes.
// a. Déclaration du type 'tns:Article' représentant un article sous forme d'un tableau associatif.
$service->wsdl->addComplexType(
    'Article',                                      // Nom du type
    'complexType',                                  // Type de base XMLSchema
    'struct',                                       // Ensemble de données simples
    'sequence',                                     // Ensemble d'éléments XMLSchema
    '',                                             // Type de base XMLSchema a restreindre. Ici, '' car on créé notre propre type.
    array(                                          // Description du type.
        'id' => array('name' => 'id', 'type' => 'xsd:int'),         // 'clé du tableau' => array('name' => 'nom param soap', 'type' => 'type XMLSchema')
        'titre' => array('name' => 'titre', 'type' => 'xsd:string'),
        'intro' => array('name' => 'intro', 'type' => 'xsd:string'),
        'texte' => array('name' => 'texte', 'type' => 'xsd:string'),
        'datePublication' => array('name' => 'datePublication', 'type' => 'xsd:string'),
        'auteur' => array('name' => 'auteur', 'type' => 'xsd:string'),
        'categorie' => array('name' => 'categorie', 'type' => 'xsd:string')
    )
);

// b. Déclaration du type 'tns:ArrayOfArticle' réprésentant un tableau d'articles sous forme de tableaux associatifs.
$service->wsdl->addComplexType(
    'ArrayOfArticle',
    'complexType',
    'array',                                        // Ensemble de types complexes !
    '',                                             // Pas de séquence XMLSchema, on va restreindre un type existant.
    'SOAP-ENC:Array',                               // Le type de base à restreindre. Ici, un tableau SOAP.
    array(),                                        // Pas de description du type puisqu'on travaillle par restriction.
    array(                                          // Decritpion de la restriction.
        array(
            'ref' => 'SOAP-ENC:arrayType',
            'wsdl:arrayType' => 'tns:Article[]'     // La seule chose qui change est la valeur de 'wsdl:arrayType' !
        )
    ),
    'tns:Article'                                   // Type de chaque éléments du tabeau.
);

// 5. Enregistrement des fonctions.
$service->register(
    'ajouter',                                              // Nom de la fonction
    array('article' => 'tns:Article'),                      // Paramètres de la fonction
    array(),                                                // Retour de la fonction
    'http://www.formation.fr/service/pol/article',          // URI d'espace de nom du service   
    'http://www.formation.fr/service/pol/article#ajouter',  // SOAP Action
    'document',
    'literal'
);

$service->register(
    'rechercherParId',                                              // Nom de la fonction
    array('id' => 'xsd:integer'),                                   // Paramètres de la fonction
    array('return' => 'tns:Article'),                               // Retour de la fonction
    'http://www.formation.fr/service/pol/article',                  // URI d'espace de nom du service
    'http://www.formation.fr/service/pol/article#rechercherParId',  // SOAP Action
    'document',
    'literal'
);

$service->register(
    'rechercherTous',                                              // Nom de la fonction
    array(),                                                       // Paramètres de la fonction
    array('return' => 'tns:ArrayOfArticle'),                       // Retour de la fonction
    'http://www.formation.fr/service/pol/article',                 // URI d'espace de nom du service
    'http://www.formation.fr/service/pol/article#rechercherTous',  // SOAP Action
    'document',
    'literal'
);

// 6. Activation du service.
$service->service(file_get_contents('php://input'));




















