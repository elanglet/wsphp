<?php

require_once('../autoload.php');

$articleDAO = DAOFactory::getInstance()->getArticleDAO();

//echo "<pre>";
//print_r($articleDAO->rechercherArticleParAuteur('elanglet'));
//echo "</pre>";
//
//echo "<hr />";

echo "<pre>";
print_r($articleDAO->rechercherArticleParCategorie('Economie'));
echo "</pre>";

echo "<hr />";

echo "<pre>";
print_r($articleDAO->rechercherArticleParId(1));
echo "</pre>";

echo "<hr />";

echo "<pre>";
print_r($articleDAO->rechercherTousLesArticles());
echo "</pre>";