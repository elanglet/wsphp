<?php

/*
 * Pas d'autoloading pour nusoap car le nom des classes et des fichiers diffère.
 */
function phpOnlineAutoloader($class) {
    
    set_include_path(
            dirname(__FILE__) . DIRECTORY_SEPARATOR . '/commons/db/'
            . PATH_SEPARATOR .
            dirname(__FILE__) . DIRECTORY_SEPARATOR . '/commons/utils/'
            . PATH_SEPARATOR .
            dirname(__FILE__) . DIRECTORY_SEPARATOR . '/model/dao/'
            . PATH_SEPARATOR .
            dirname(__FILE__) . DIRECTORY_SEPARATOR . '/model/to/'
            . PATH_SEPARATOR .
            dirname(__FILE__) . DIRECTORY_SEPARATOR . '/service/soap/'            
            . PATH_SEPARATOR .
            dirname(__FILE__) . DIRECTORY_SEPARATOR . '/service/rest/'
            . PATH_SEPARATOR .
            dirname(__FILE__) . DIRECTORY_SEPARATOR . '/service/utils/'                                                 
            . PATH_SEPARATOR .
            get_include_path()
    );
    

    require_once($class . '.php');

}

spl_autoload_register('phpOnlineAutoloader');

set_include_path(
        dirname(__FILE__) . DIRECTORY_SEPARATOR . '/lib/nusoap/'                                                 
        . PATH_SEPARATOR .
        get_include_path()
);

require_once('nusoap.php');

